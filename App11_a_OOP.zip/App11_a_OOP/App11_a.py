from flask import Flask, render_template
import threading, time, datetime
import pandas as pd
import Class_Database, Class_Scrapping

app = Flask(__name__)
# Defining Objects
obj1 = Class_Scrapping.Scrape()
obj2 = Class_Scrapping.Scrape()
# Declaring Lists
l1 =[]
l2 = []

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
soup = obj1.Soup_Maker("https://www.exchangerates.org.uk/USD-PKR-exchange-rate-history.html")
all = soup.find_all("table",{"id":"hist"})
# the table has values in alternate colone and coltwo order so we will use two lists to store data in them individaully
list1 = all[0].find_all("tr",{"class":"colone"}) # for colone in table
list2 = all[0].find_all("tr",{"class":"coltwo"}) # for coltwo in table

obj1.Exchange_Rate(list1, "USD-PKR", "1 USD = ", " PKR", l1)
obj1.Exchange_Rate(list2, "USD-PKR", "1 USD = ", " PKR", l1)
obj1.Save_To_CSV(l1, "Exchange_Rates_USD_to_PKR.csv")

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
soup = obj2.Soup_Maker("https://www.exchangerates.org.uk/PKR-USD-exchange-rate-history.html")
all = soup.find_all("table",{"id":"hist"})
# the table has values in alternate colone and coltwo order so we will use two lists to store data in them individaully
list3 = all[0].find_all("tr",{"class":"colone"}) # for colone in table
list4 = all[0].find_all("tr",{"class":"coltwo"}) # for coltwo in table

obj2.Exchange_Rate(list3, "PKR-USD", "1 PKR = ", " USD", l2)
obj2.Exchange_Rate(list4, "PKR-USD", "1 PKR = ", " USD", l2)
obj2.Save_To_CSV(l2, "Exchange_Rates_PKR_to_USD.csv")

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def Doll():
    global pkr

    while True:
        live_obj = Class_Scrapping.Scrape()
        soup = live_obj.Soup_Maker("https://www.x-rates.com/table/?from=USD&amount=1")
        all = soup.find("table",{"class":"tablesorter ratesTable"})
        
        try:
            if all.text is not None:
                usd = all.text
                usd = usd.split()
                index = usd.index("Pakistani")
                pkr = usd[index+2:index+4]
        except:
            pkr = [None,None]

        print("-----------------")
        print(pkr[0])
        print(pkr[1])
        print("-----------------")
        db = Class_Database.Database("lite.db")
        currentDateTime = datetime.datetime.now()
        db.Insert_Values(float(pkr[0]), float(pkr[1]), currentDateTime)
        db.Updated_Live_Data()
        time.sleep(25)

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

@app.route('/')
def home():
    return render_template('index.html', PKRt = pkr[1], USDt = pkr[0])

@app.route('/back', methods = ["POST"])
def back():
    return render_template('index.html', USDt = pkr[0], PkRt = pkr[1])

@app.route('/show_data')
def showData():
    return render_template("plot.html", y = Class_Database.Dollar_rate[-50:], x = Class_Database.time_stamp[-50:])

@app.route('/weekly_data')
def weeklyData():
    data = pd.read_csv("Exchange_Rates_USD_to_PKR.csv", parse_dates = ['Date'])
    data['Week'] = data['Date'].dt.strftime('%U - %Y') # %U --> Week number of the year (Sunday as the first day of the week)
    wk_Avg = data.groupby(['Week']).mean()
    return render_template("weekly_plot.html", y = list(wk_Avg['USD-PKR']), x = list(wk_Avg.index))

@app.route('/monthly_data')
def monthlyData():
    data = pd.read_csv("Exchange_Rates_USD_to_PKR.csv", parse_dates = ['Date'])
    data['Month'] = data['Date'].dt.strftime('%m - %Y')
    Mnt_Avg = data.groupby(['Month']).mean()
    return render_template("monthly_plot.html", y = list(Mnt_Avg['USD-PKR']), x = list(Mnt_Avg.index))

if __name__ == "__main__":
    thread1 = threading.Thread(target=Doll).start()
    thread2 = threading.Thread(target=app.run(debug=True)).start()