import sqlite3

class Database:
    def __init__(self, dtb):
        self.conn = sqlite3.connect(dtb)
        self.cur = self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS database (USD_Exchnage_Rate INTEGER, PKR_Exchange_Rate INTEGER, Time TEXT)")
        self.conn.commit() #  make sure the changes made to the database

    def Insert_Values(self, usd, Rs, tym):
        self.cur.execute("INSERT INTO database VALUES(?,?,?)",(usd, Rs, tym,))
        self.conn.commit()

    def Updated_Live_Data(self):
        self.cur.execute("SELECT * FROM database")
        result = list(self.cur.fetchall())
        global Dollar_rate, Rupee_rate, time_stamp
        Dollar_rate = [i[0] for i in result]
        Rupee_rate = [i[1] for i in result]
        time_stamp = [i[2] for i in result]

    def __del__(self):
        self.conn.close()