import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime

class Scrape:
    def Soup_Maker(self, URL):
        self.r = requests.get(URL)
        self.c = self.r.content
        self.soup = BeautifulSoup(self.c, "html.parser")
        return self.soup

    def Exchange_Rate(self, LIST, col, repl_1, repl_2, lst):
        for i in LIST:    
            d = {}
            date_time_str = i.find_all("td")[0].text
            date_time_obj = datetime.strptime(date_time_str, '%A %d %B %Y')
            d["Date"] = date_time_obj
            d[col] = i.find_all("td")[1].text.replace(repl_1,"").replace(repl_2,"")
            lst.append(d)

    def Save_To_CSV(self, LIST, filename):
        df = pd.DataFrame(LIST)
        df = df.sort_values(['Date'], ascending=False) #Sorting according to dates
        df.to_csv(filename, index=False)