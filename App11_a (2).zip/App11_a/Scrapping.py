import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime

def Web_Scrapping(URL):
    r = requests.get(URL)
    c = r.content
    soup = BeautifulSoup(c, "html.parser")
    all = soup.find_all("table",{"id":"hist"})
    return all

def Exchange_Rate_USD(LIST):
    for i in LIST:    
        d = {}
        date_time_str = i.find_all("td")[0].text
        date_time_obj = datetime.strptime(date_time_str, '%A %d %B %Y')
        d["Date"] = date_time_obj
        d["USD-PKR"] = i.find_all("td")[1].text.replace("1 USD = ","").replace(" PKR","")
        l1.append(d)

def Exchange_Rate_PKR(LIST):
    for i in LIST:    
        d = {}
        date_time_str = i.find_all("td")[0].text
        date_time_obj = datetime.strptime(date_time_str, '%A %d %B %Y')
        d["Date"] = date_time_obj
        d["PKR-USD"] = i.find_all("td")[1].text.replace("1 PKR = ","").replace(" USD","")
        l2.append(d)

def Save_To_CSV(LIST, filename):
    df = pd.DataFrame(LIST)
    df = df.sort_values(['Date'], ascending=False) #Sorting according to dates
    df.to_csv(filename, index=False)

l1 =[]
x1 = Web_Scrapping("https://www.exchangerates.org.uk/USD-PKR-exchange-rate-history.html")

# the table has values in alternate colone and coltwo order so we will use two lists to store data in them individaully
list1 = x1[0].find_all("tr",{"class":"colone"}) # for colone in table
list2 = x1[0].find_all("tr",{"class":"coltwo"}) # for coltwo in table

Exchange_Rate_USD(list1)
Exchange_Rate_USD(list2)
Save_To_CSV(l1, "Exchange_Rates_USD_to_PKR.csv")
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

l2 = []
x2 = Web_Scrapping("https://www.exchangerates.org.uk/PKR-USD-exchange-rate-history.html")

# the table has values in alternate colone and coltwo order so we will use two lists to store data in them individaully
list3 = x2[0].find_all("tr",{"class":"colone"}) # for colone in table
list4 = x2[0].find_all("tr",{"class":"coltwo"}) # for coltwo in table

Exchange_Rate_PKR(list3)
Exchange_Rate_PKR(list4)
Save_To_CSV(l2, "Exchange_Rates_PKR_to_USD.csv")