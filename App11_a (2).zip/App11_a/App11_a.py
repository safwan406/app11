from flask import Flask, render_template, request
from bs4 import BeautifulSoup
import requests
import Scrapping
import threading, time
import sqlite3, datetime
import pandas as pd

app = Flask(__name__)

def Create_Table():
    conn = sqlite3.connect("lite.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS database (USD_Exchnage_Rate INTEGER, PKR_Exchange_Rate INTEGER, Time TEXT)")
    conn.commit() #  make sure the changes made to the database
    conn.close()

def Insert_Values(usd, Rs, tym):
    conn = sqlite3.connect("lite.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO database VALUES(?,?,?)",(usd, Rs, tym,))
    conn.commit()
    conn.close()

def Updated_Values():
    conn = sqlite3.connect("lite.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM database")
    result = list(cur.fetchall())
    global Dollar_rate, Rupee_rate, time_stamp
    Dollar_rate = [i[0] for i in result]
    #print(Dollar_rate)
    Rupee_rate = [i[1] for i in result]
    #print(Rupee_rate)
    time_stamp = [i[2] for i in result]
    #print(time_stamp)

def Doll():
    global pkr

    while True:
        r = requests.get("https://www.x-rates.com/table/?from=USD&amount=1")
        c = r.content
        soup = BeautifulSoup(c, "html.parser")
        try:
            if soup.find("table", {"class" : "tablesorter ratesTable"}).text is not None:
                usd = soup.find("table", {"class" : "tablesorter ratesTable"}).text
                usd = usd.split()
                index = usd.index("Pakistani")
                pkr = usd[index+2:index+4]

        except:
            pkr = [None,None]

        print("-----------------")
        print(pkr[0])
        print(pkr[1])
        print("-----------------")

        Create_Table()
        currentDateTime = datetime.datetime.now()
        #print(currentDateTime)
        Insert_Values(float(pkr[0]), float(pkr[1]), currentDateTime)
        Updated_Values()
        time.sleep(60)

@app.route('/')
def home():
    return render_template('index.html', PKRt = pkr[1], USDt = pkr[0])

@app.route('/back', methods = ["POST"])
def back():
    return render_template('index.html', USDt = pkr[0], PkRt = pkr[1])

@app.route('/show_data')
def showData():
    return render_template("plot.html", y = Dollar_rate[-200:], x = time_stamp[-200:])

@app.route('/weekly_data')
def weeklyData():
    data = pd.read_csv("Exchange_Rates_USD_to_PKR.csv", parse_dates = ['Date'])
    data['Week'] = data['Date'].dt.strftime('%U - % Y')
    wk_Avg = data.groupby(['Week']).mean()
    return render_template("weekly_plot.html", y = list(wk_Avg['USD-PKR']), x = list(wk_Avg.index))

@app.route('/monthly_data')
def monthlyData():
    data = pd.read_csv("Exchange_Rates_USD_to_PKR.csv", parse_dates = ['Date'])
    data['Month'] = data['Date'].dt.strftime('%m - %Y')
    Mnt_Avg = data.groupby(['Month']).mean()
    return render_template("monthly_plot.html", y = list(Mnt_Avg['USD-PKR']), x = list(Mnt_Avg.index))

if __name__ == "__main__":
    thread1 = threading.Thread(target=Doll).start()
    thread2 = threading.Thread(target=app.run(debug=True)).start()