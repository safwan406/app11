from flask import Flask, render_template, request
from bs4 import BeautifulSoup
import Scrapping, requests
import threading, time
import sqlite3, datetime

app = Flask(__name__)

def Create_Table():
    conn = sqlite3.connect("lite.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS database (USD_Exchnage_Rate INTEGER, PKR_Exchange_Rate INTEGER, Time TEXT)")
    conn.commit() #  make sure the changes made to the database
    conn.close()

def Insert_Values(usd, Rs, tym):
    conn = sqlite3.connect("lite.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO database VALUES(?,?,?)",(usd, Rs, tym,))
    conn.commit()
    conn.close()

def Updated_Values():
    conn = sqlite3.connect("lite.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM database")
    result = list(cur.fetchall())
    global Dollar_rate, Rupee_rate, time_stamp
    Dollar_rate = [i[0] for i in result]
    Rupee_rate = [i[1] for i in result]
    time_stamp = [i[2] for i in result]

def Doll():
    global pkr

    while True:
        # r = requests.get("https://www.google.com/finance/quote/USD-PKR?sa=X&ved=2ahUKEwjGt8is3JP6AhVDxQIHHfPLCioQmY0JegQICBAb")
        # c = r.content
        # soup = BeautifulSoup(c, "html.parser")
        # global USDt
        
        # if soup.find("div",{"class":"YMlKec fxKbKc"}).text is not None:
        #     USDt = soup.find("div",{"class":"YMlKec fxKbKc"}).text
        #     print(USDt)
        r = requests.get("https://www.x-rates.com/table/?from=USD&amount=1")
        c = r.content
        soup = BeautifulSoup(c, "html.parser")

        if soup.find("table", {"class" : "tablesorter ratesTable"}).text is not None:
            usd = soup.find("table", {"class" : "tablesorter ratesTable"}).text
            usd = usd.split()
            index = usd.index("Pakistani")
            pkr = usd[index+2:index+4]

        else:
            pkr = [None,None]

        print("-----------------")
        print(pkr[0])
        print(pkr[1])
        print("-----------------")

        Create_Table()
        currentDateTime = datetime.datetime.now()
        #print(currentDateTime)
        Insert_Values(float(pkr[0]), float(pkr[1]), currentDateTime)
        Updated_Values()
        time.sleep(60)

@app.route('/')
def home():
    return render_template('index.html', PKRt = pkr[1], USDt = pkr[0])

@app.route('/back', methods = ["POST"])
def back():
    return render_template('index.html', USDt = pkr[0], PkRt = pkr[1])

@app.route('/show_data',  methods=["POST"])
def showData():

    try:
        if request.method == 'POST':
            
            history = Scrapping.df
            return render_template("plot.html", his = history.to_html(), y = Dollar_rate, x = time_stamp)
    except:
        return render_template("index.html")


if __name__ == "__main__":
    
    thread1 = threading.Thread(target=Doll).start()
    thread2 = threading.Thread(target=app.run(debug=True)).start()