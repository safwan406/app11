import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt


r = requests.get("https://www.exchangerates.org.uk/USD-PKR-exchange-rate-history.html")
c = r.content
soup = BeautifulSoup(c, "html.parser")

all = soup.find_all("table",{"id":"hist"})

list1 = all[0].find_all("tr",{"class":"colone"})
list2 = all[0].find_all("tr",{"class":"coltwo"})

x = len(list1)
y = len(list2)
l =[]

for i in range(x):    
    d = {}
    date_time_str = list1[i].find_all("td")[0].text
    date_time_obj = datetime.strptime(date_time_str, '%A %d %B %Y')
    d["Date"] = date_time_obj
    d["Price"] = list1[i].find_all("td")[1].text.replace("1 USD = ","").replace(" PKR","")
    l.append(d)

for i in range(y):    
    d = {}
    date_time_str = list2[i].find_all("td")[0].text
    date_time_obj = datetime.strptime(date_time_str, '%A %d %B %Y')
    d["Date"] = date_time_obj
    d["Price"] = list2[i].find_all("td")[1].text.replace("1 USD = ","").replace(" PKR","")
    l.append(d)

#print(l)

df = pd.DataFrame(l)
df = df.sort_values(['Date'], ascending=False)
df.to_csv("Cost_per_USD.csv", index=False)

df["Price"]= df["Price"].astype(float) # plot was using prices as String type so we converted it into float
df.plot(x ='Date', y='Price', kind = 'area')
# plt.show()
# plt.savefig('my_plot.png')